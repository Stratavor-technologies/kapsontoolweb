import { useState, useEffect, useRef } from 'react';
import Contact from '../assets/Images/Contact.png';
import Cart from '../assets/Images/Cart.png';
import Profile from '../assets/Images/Profile.png';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
    const [activeDropdown, setActiveDropdown] = useState(null);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const navbarRef = useRef(null);
    const menuRef = useRef(null);
    const navigate = useNavigate();

    useEffect(() => {
        const handleScroll = () => {
            if (navbarRef.current) {
                if (window.scrollY > 20) {
                    navbarRef.current.classList.add('navbar-scrolled');
                } else {
                    navbarRef.current.classList.remove('navbar-scrolled');
                }
            }
        };

        const handleClickOutside = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target) &&
                !event.target.closest('.hamburger-3d-container')) {
                setMobileMenuOpen(false);
            }
        };

        window.addEventListener('scroll', handleScroll);
        document.addEventListener('mousedown', handleClickOutside);

        return () => {
            window.removeEventListener('scroll', handleScroll);
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    // Handle screen resize
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 768 && mobileMenuOpen) {
                setMobileMenuOpen(false);
            }
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, [mobileMenuOpen]);

    const toolsCategories = [
        {
            category: "Power Tools",
            id: "power-tools"
        },
        {
            category: "Hand Tools",
            id: "hand-tools"
        },
        {
            category: "Safety Equipment",
            id: "safety-equipment"
        },
        {
            category: "Machinery",
            id: "machinery"
        }
    ];

    const toggleMobileMenu = () => {
        setMobileMenuOpen(!mobileMenuOpen);
    };

    // Navigate to a category page
    const handleCategoryClick = (categoryId) => {
        navigate(`/Subcategories/${categoryId}`);
        setActiveDropdown(null);
        setMobileMenuOpen(false);
    };

    return (
        <nav className="navbar-3d" ref={navbarRef}>
            <div className="navbar-container flex justify-between items-center w-full px-4 sm:px-6 md:px-8 lg:px-12">
                <div className="navbar-logo flex-shrink-0">
                    <div className="logo-3d">
                        <span className="logo-front">Industrial</span>
                        <span className="logo-back">Pro</span>
                    </div>
                </div>

                {/* 3D Hamburger Menu Button */}
                <div className="lg:hidden relative z-50">
                    <button
                        className="hamburger-3d-container"
                        onClick={toggleMobileMenu}
                        aria-label="Toggle menu"
                        aria-expanded={mobileMenuOpen}
                    >
                        <div className={`hamburger-3d ${mobileMenuOpen ? 'open' : ''}`}>
                            <span className="layer top"></span>
                            <span className="layer middle"></span>
                            <span className="layer bottom"></span>
                        </div>
                    </button>
                </div>

                {/* Desktop Menu */}
                <div className="hidden lg:flex navbar-menu">
                    <div className="menu-item">
                        <a onClick={() => navigate("/")} className="menu-link cursor-pointer">Home</a>
                    </div>

                    <div className="menu-item"
                        onMouseEnter={() => setActiveDropdown(0)}
                        onMouseLeave={(e) => {
                            // Check if the cursor is moving toward the dropdown
                            const dropdown = e.currentTarget.querySelector('.dropdown-3d');
                            if (dropdown) {
                                const dropdownRect = dropdown.getBoundingClientRect();
                                // Give a small buffer for the mouse to enter dropdown
                                if (!(e.clientY >= dropdownRect.top &&
                                    e.clientY <= dropdownRect.bottom &&
                                    e.clientX >= dropdownRect.left &&
                                    e.clientX <= dropdownRect.right)) {
                                    setActiveDropdown(null);
                                }
                            } else {
                                setActiveDropdown(null);
                            }
                        }}>
                        <a onClick={() => navigate("/Categorie")} className="menu-link cursor-pointer">Industrial Tools</a>

                        {activeDropdown === 0 && (
                            <div className="dropdown-3d"
                                onMouseLeave={() => setActiveDropdown(null)}
                                onMouseEnter={() => setActiveDropdown(0)}>
                                <div className="dropdown-container">
                                    <div className="">
                                        <h3 className="dropdown-heading font-bold mb-2">Categories</h3>
                                        <ul className="dropdown-list">
                                            {toolsCategories.map((category, index) => (
                                                <li key={index} className="dropdown-item">
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation(); // Prevent event bubbling
                                                            handleCategoryClick(category.id);
                                                            console.log("hello")
                                                        }}
                                                        className="text-gray-600 hover:text-blue-500 cursor-pointer"
                                                    >
                                                        {category.category}
                                                    </button>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                    <div className="menu-item">
                        <a onClick={() => navigate("/Aboutus")} className="menu-link cursor-pointer">About Us</a>
                    </div>

                    {/* <div className="menu-item text-red">
                        <a onClick={() => navigate("/Services")} className="menu-link cursor-pointer">Services</a>
                    </div> */}
                </div>

                {/* Mobile/Tablet Menu - Sliding Panel */}
                <div
                    ref={menuRef}
                    className={`lg:hidden fixed top-0 right-0 h-auto w-full sm:w-4/5 md:w-3/5 bg-white shadow-2xl z-40 transform transition-transform duration-500 ease-in-out ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}
                >
                    <div className="h-full overflow-y-auto">
                        {/* Mobile Menu Header */}
                        <div className="flex justify-between items-center p-4 border-b border-gray-200">
                            <div className="text-2xl font-bold">Menu</div>
                            <button
                                onClick={toggleMobileMenu}
                                className="close-button text-2xl"
                                aria-label="Close menu"
                            >
                                &times;
                            </button>
                        </div>

                        {/* Mobile Menu Items */}
                        <div className="flex flex-col p-4">
                            <a onClick={() => navigate("/")} className="mobile-menu-item py-3 px-4 border-b border-gray-200 hover:bg-gray-100" style={{ "--item-index": 0 }}>Home</a>

                            <div className="mobile-menu-item py-3 px-4 border-b border-gray-200" style={{ "--item-index": 1 }}>
                                <div
                                    className="flex justify-between items-center"
                                    onClick={() => setActiveDropdown(activeDropdown === 0 ? null : 0)}
                                >
                                    <span className="cursor-pointer" onClick={() => navigate("/categories")}>Industrial Tools</span>
                                    <span className={`transform transition-transform duration-300 ${activeDropdown === 0 ? 'rotate-180' : ''}`}>
                                        ▼
                                    </span>
                                </div>

                                {activeDropdown === 0 && (
                                    <div className="mt-2 ml-4 animate-fadeIn">
                                        <h3 className="font-semibold text-gray-800 mb-2">Categories</h3>
                                        <ul className="ml-4 mt-1">
                                            {toolsCategories.map((category, index) => (
                                                <li key={index} className="py-2">
                                                    <a
                                                        onClick={() => handleCategoryClick(category.id)}
                                                        className="text-gray-600 hover:text-blue-500 cursor-pointer"
                                                    >
                                                        {category.category}
                                                    </a>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>

                            <a onClick={() => navigate("/Aboutus")} className="mobile-menu-item py-3 px-4 border-b border-gray-200 hover:bg-gray-100" style={{ "--item-index": 2 }}>About Us</a>
                            {/* <a onClick={() => navigate("/Services")} className="mobile-menu-item py-3 px-4 border-b border-gray-200 hover:bg-gray-100 text-red-500" style={{ "--item-index": 4 }}>Services</a> */}
                        </div>

                        {/* Mobile Menu Footer with Contact Info */}
                        <div className="p-4 mt-4 bg-gray-50">
                            <div className="text-sm text-gray-600 mb-2">📞 +91 98765 43210</div>
                            <div className="text-sm text-gray-600">📧 contact@company.com</div>
                        </div>
                    </div>
                </div>

                {/* Overlay for mobile menu */}
                {mobileMenuOpen && (
                    <div
                        className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
                        onClick={toggleMobileMenu}
                    ></div>
                )}

                {/* Icons - Responsive */}
                <div className="flex items-center space-x-2 sm:space-x-3 md:space-x-4">
                    {/* Contact Dropdown */}
                    <div className="relative group">
                        <img className="h-[30px] sm:h-[40px] md:h-[50px] lg:h-[60px] cursor-pointer" src={Contact} alt="Contact" />
                        <div className="absolute top-[40px] sm:top-[50px] md:top-[60px] lg:top-[70px]  right-0 lg:right-auto lg:left-0 w-60 bg-white border border-gray-200 rounded-xl shadow-lg scale-y-0 opacity-0 transform origin-top transition-all duration-300 group-hover:scale-y-100 group-hover:opacity-100 z-10 p-4">
                            <p className="text-gray-700 hover:text-blue-500 cursor-pointer">📞 +91 98765 43210</p>
                            <p className="text-gray-700 hover:text-blue-500 cursor-pointer mt-2">📧 contact@company.com</p>
                        </div>
                    </div>

                   <div onClick={() => navigate("/ProductCart")}>
                   <img className="h-[25px] cursor-pointer sm:h-[30px] md:h-[40px] lg:h-[50px]" src={Cart} alt="Cart" />
                   </div>

                    {/* Profile Dropdown */}
                    <div className="relative group">
                        <img className="h-[25px] sm:h-[30px] md:h-[40px] lg:h-[50px] cursor-pointer" src={Profile} alt="Profile" />
                        <div className="absolute top-[35px] sm:top-[40px] md:top-[50px] lg:top-[60px] right-0 lg:right-auto lg:left-0 w-40 bg-white border border-gray-200 rounded-xl shadow-lg scale-y-0 opacity-0 transform origin-top transition-all duration-300 group-hover:scale-y-100 group-hover:opacity-100 z-10 p-4">
                            <button onClick={() => navigate("/Login")}>
                                <p className="text-gray-700  hover:text-blue-500 cursor-pointer">🔐 Login</p>
                            </button>
                           
                            <button onClick={() => navigate("/Singup")}>
                            <p className="text-gray-700 pb-2 hover:text-blue-500 cursor-pointer mt-2">📝 Signup</p>
                            </button>
                            <button onClick={() => navigate("/Order")}>
                            <p className="text-gray-700 pb-2 hover:text-blue-500 cursor-pointer">⏳ Order History</p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;