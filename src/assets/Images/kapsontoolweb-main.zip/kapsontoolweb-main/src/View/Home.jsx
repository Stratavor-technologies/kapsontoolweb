import React, { useState, useRef } from 'react';
import Carousel3D from '../Components/Carousel'; // Adjust the import path as needed

// Import your images
import image1 from '../assets/Images/banner1.png';
import image2 from '../assets/Images/banner2.jpg';
import image3 from '../assets/Images/tool3.webp';
import image4 from '../assets/Images/show.jpeg';
import show from '../assets/Images/show2.webp';
import Recommend from '../Components/Recommend';
import CustomerReviews from '../Components/CustomerReviews';
import QualityCertificates3D from '../Components/Quality';

const Home = () => {
  const [showSecondImage, setShowSecondImage] = useState(false);
  const isHoveredRef = useRef(false); // Use a ref to track hover state

  const handleMouseEnter = () => {
    isHoveredRef.current = true;
    setTimeout(() => {
      if (isHoveredRef.current) {
        setShowSecondImage(true);
      }
    }, 1000); // 2 seconds delay
  };

  const handleMouseLeave = () => {
    isHoveredRef.current = false;
    setShowSecondImage(false);
  };

  // Create an array of image objects with captions
  const carouselImages = [
    { src: image1, alt: "Tools" },
    { src: image2, alt: "Second Image" },
    // { src: image3, alt: "Third Image" },
  ];

  return (
    <>
      <Carousel3D images={carouselImages} />
      <div className="flex flex-col items-center justify-center py-10">
        <div className="relative">
          {/* Industrial */}
          <div className="text-orange-300 font-bold transform rotate-x-20 rotate-y-[-10deg] pt-10  ranslate-z-[50px] animate-slideFromLeft">
            <span className="text-5xl md:text-8xl lg:text-[120px] xl:text-[200px]">INDUSTRIAL</span>
          </div>

          {/* Tools */}
          <div className="absolute top-0 left-10 sm:left-20 md:left-32 lg:left-40 xl:left-48 transform rotate-x-20 rotate-y-[-10deg] translate-z-[-50px] animate-slideFromRight">
            <span className="text-6xl md:text-9xl lg:text-[140px] xl:text-[230px] font-bold">TOOLS</span>
          </div>
        </div>
      </div>
      <div className="flex flex-col lg:flex-row justify-between py-8 px-5 lg:py-20 lg:px-20 gap-10 lg:gap-0">
        <div
          className="h-[400px] sm:h-[500px] lg:h-[800px] w-full sm:w-[500px] lg:w-[700px] rounded-lg perspective"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          <div className={`relative w-full h-full transform-style-3d transition-transform duration-1000 ${showSecondImage ? 'rotate-y-180' : ''}`}>
            {/* Front Image */}
            <img
              src={image4}
              alt="Belding Tool"
              className="rounded-xl w-full h-full object-cover absolute backface-hidden"
            />
            {/* Back Image */}
            <img
              src={show}
              alt="Second Image"
              className="rounded-xl w-full h-full object-cover absolute backface-hidden transform rotate-y-180"
            />
          </div>
        </div>

        <div className="max-w-full lg:max-w-[600px]">
          <h1 className="text-3xl sm:text-5xl lg:text-[60px] font-bold mb-4 sm:mb-6">Our Speciality</h1>
          <div className="text-sm sm:text-base lg:text-lg mb-4 sm:mb-8">
            At our core, we are committed to delivering high-performance industrial tools that stand out for their quality, durability, and precision.
            Our tools are designed to meet the demanding needs of industries, ensuring they provide maximum efficiency and long-lasting performance.
            We believe that honesty and dedication are the foundation of great workmanship.
            That's why every tool we create undergoes strict quality checks to ensure it meets industry standards and exceeds customer expectations.
            <br /><br />
            Our team combines technical expertise with innovative design to develop tools that simplify complex tasks and improve productivity.
            Whether you're working in manufacturing, construction, or any other industrial sector, our solutions are tailored to help you achieve better results with minimal effort.
            <br /><br />
            We take pride in our transparent approach, ensuring that our customers receive exactly what they are promised — tools that perform consistently and reliably.
            By focusing on precision engineering and user-friendly designs, we strive to make your job easier and more efficient.
            <br /><br />
            When you choose our tools, you're not just investing in a product — you're gaining a trusted partner dedicated to supporting your success.
            Experience the difference that quality craftsmanship, honest work, and innovative design can make in your industry.
          </div>

          <div className="text-sm sm:text-base lg:text-lg">
            <div className="flex items-center mb-2">
              <span className="mr-2">✅</span>
              <span>Enhanced Precision: Ensures accurate alignment and seamless bonding.</span>
            </div>
            <div className="flex items-center mb-2">
              <span className="mr-2">✅</span>
              <span>Time Efficiency: Speeds up the belding process, reducing manual effort.</span>
            </div>
          </div>
        </div>
      </div>

      <Recommend />
      <CustomerReviews />
      <QualityCertificates3D />
    </>
  );
};

export default Home;