import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Navbar from './Components/Navbar';
import Footer from './Components/Footer';
import WhatsAppChatWidget from './Components/WhatsAppChat'; // Import the widget
import styled from 'styled-components';

// Import your pages
import HomePage from './View/Home';
import LoginPage from './Components/Login';
import ForgotPassword from './Components/ForgotPassword';
import OtpVerification from './Components/OtpVerification'
import Singup from './Components/Singup';
import AboutUsPage from './View/About';
import ContactUsPage from './View/Contact';
import Subcategories from './View/SubCategory';
import Categorie from './View/Category';
import ProductsPage from './View/Products';
import ProductView from './View/ProductView';
import ProductCard from './View/ProductCart';
import Checkout from './View/Checkout';
import Order from './View/Order';
import Paymentdone from './View/Paymentdone';

const AppContainer = styled.div`
  width: 100%;
  min-height: 100vh;
  position: relative;
  display: flex;
  flex-direction: column;
`;

const ContentContainer = styled.div`
  flex: 1;
`;

// Layout component to conditionally render navbar and footer
const Layout = ({ children }) => {
  const location = useLocation();
  const authRoutes = ['/login', '/Singup', '/ForgotPassword'];
  const hideNavbarAndFooter = authRoutes.includes(location.pathname);

  return (
    <div className={`app ${hideNavbarAndFooter ? '' : 'pt-[10vh]'}`} style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {!hideNavbarAndFooter && <Navbar />}
      <div className="flex-1">
        {children}
      </div>
      {!hideNavbarAndFooter && <Footer />}

      {/* Add WhatsApp Chat Widget here, it will be displayed on all pages */}
      <WhatsAppChatWidget
        phoneNumber="YOUR_PHONE_NUMBER_HERE"
        message="Hi, I'd like to learn more about your services."
      />
    </div>
  );
};

function App() {
  return (
    <BrowserRouter>
      <AppContainer>
        <Routes>
          <Route path="/" element={
            <Layout>
              <HomePage />
            </Layout>
          } />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/ForgotPassword" element={<ForgotPassword />} />
          <Route path="/OtpVerification" element={<OtpVerification />} />
          <Route path="/Singup" element={<Singup />} />
          <Route path="/Aboutus" element={
            <Layout>
              <AboutUsPage />
            </Layout>
          } />
          <Route path="/ProductCart" element={
            <Layout>
              <ProductCard />
            </Layout>
          } />
          <Route path="/Checkout" element={
            <Layout>
              <Checkout />
            </Layout>
          } />
          <Route path="/Order" element={
            <Layout>
              <Order />
            </Layout>
          } />
          <Route path="/Payment" element={
            <Layout>
              <Paymentdone />
            </Layout>
          } />

          <Route path="/Contact" element={
            <Layout>
              <ContactUsPage />
            </Layout>
          } />
          <Route path="/Categorie" element={
            <Layout>
              <Categorie />
            </Layout>
          } />

          {/* Update the ProductsPage route to match your Subcategories navigation */}
          <Route path="/ProductDetails/:categoryId/:subcategoryId" element={
            <Layout>
              <ProductsPage />
            </Layout>
          } />
          <Route path="/product/:productId" element={
            <Layout>
              <ProductView />
            </Layout>} />

          <Route
            path="/Subcategories/:categoryId"
            element={
              <Layout>
                <Subcategories />
              </Layout>
            }
          />

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </AppContainer>
    </BrowserRouter>
  );
}

export default App;